package com.rsl 

import groovy.json.JsonBuilder
import org.bonitasoft.engine.identity.User
import org.bonitasoft.engine.identity.UserCriterion
import org.bonitasoft.engine.identity.UserMembership;
import org.bonitasoft.engine.identity.UserMembershipCriterion;
import org.bonitasoft.engine.identity.UserSearchDescriptor
import org.bonitasoft.engine.search.SearchOptionsBuilder
import org.bonitasoft.web.extension.rest.RestAPIContext
import org.bonitasoft.web.extension.rest.RestApiController
import org.bonitasoft.web.extension.rest.RestApiResponse
import org.bonitasoft.web.extension.rest.RestApiResponseBuilder
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import javax.servlet.http.HttpServletRequest

public class GetUsers implements RestApiController {

	
	private static final Logger LOGGER = LoggerFactory.getLogger("org.bonitasoft")

	@Override
	RestApiResponse doHandle(HttpServletRequest request, RestApiResponseBuilder responseBuilder, RestAPIContext context) {

		// User session to get the user Bonita id to search for managed employee vacation requests
		def apiClient = context.apiClient

		// Get a reference to IdentityAPI to search for users managed by current user
		def identityAPI = apiClient.identityAPI

		// Get a reference to ProcessAPI to search for task id based on process instance id
		def processAPI = apiClient.processAPI

		// Current user id
		List<User> usersAll = identityAPI.getUsers(0, identityAPI.getNumberOfUsers().toInteger(),  UserCriterion.LAST_NAME_ASC);
		LOGGER.error(usersAll.size().toString());

		List<Map> resp = [];
		for (User u : usersAll) {
			Map<String,String> userdata = new HashMap();
			userdata.put("id", u.id.toString());
			userdata.put("lastName", u.getLastName());
			userdata.put("firstName", u.getFirstName());
			userdata.put("jobTitle", u.getJobTitle());
			userdata.put("lastConnection", u.getLastConnection());
			resp.add(userdata);
		}
		
		responseBuilder.with {
			withResponse new JsonBuilder(resp).toPrettyString()
			build()
		}
	}

}
